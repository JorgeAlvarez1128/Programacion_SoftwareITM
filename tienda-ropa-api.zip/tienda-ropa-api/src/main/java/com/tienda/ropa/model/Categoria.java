package com.tienda.ropa.model;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class Categoria {
    private Integer categoriaId;
    private String nombre;
}
