package com.tienda.ropa.model;
import lombok.*;

@Data @NoArgsConstructor @AllArgsConstructor
public class Rol {
    private Integer roleId;
    private String nombre;
}
